import React from 'react';
import NaturalQuery from './NaturalQuery';  // Import the NaturalQuery component
import './App.css';

function App() {
  return (
    <div>
      <NaturalQuery />  {/* Render the NaturalQuery component */}
    </div>
  );
}

export default App;
