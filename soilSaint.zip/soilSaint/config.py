class Config:
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'YusefB'
    MYSQL_PASSWORD = 'YUSEFBAYYAT2006'
    MYSQL_DB = 'soilsaint'
